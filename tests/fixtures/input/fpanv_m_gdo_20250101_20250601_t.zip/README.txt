Please note that these data have a global coverage ( -180, -55.9166, 180, 90) and a spatial resolution of 1/12 decimal degree ( 0.08333 decimal degree ).

See https://data.jrc.ec.europa.eu/dataset/133c2705-bdc2-4f28-a35f-029dbba32d00 and https://data.jrc.ec.europa.eu/dataset/ea144baf-f8f4-4451-aefe-fc20edcc8cc7 for details.
